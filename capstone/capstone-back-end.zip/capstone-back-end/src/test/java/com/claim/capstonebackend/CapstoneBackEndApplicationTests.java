package com.claim.capstonebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
